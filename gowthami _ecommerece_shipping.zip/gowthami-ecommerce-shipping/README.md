# E-Commerce Shipping Charge Estimator (Spring Boot)

## Project Description
This application calculates shipping charges based on distance, delivery type (Standard/Express), and product weight.

## How to Run
1. Open project in IDE (IntelliJ / Eclipse)
2. Run EcommerceApplication.java
3. Use Postman to test APIs

## Tech Stack
- Java
- Spring Boot
- Maven

Prepared for academic submission.
