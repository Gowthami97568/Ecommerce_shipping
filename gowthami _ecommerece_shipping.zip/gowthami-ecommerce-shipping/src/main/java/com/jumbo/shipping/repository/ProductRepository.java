// Modified by Gowthami
package com.gowthami.ecommerce.repository;

import com.gowthami.ecommerce.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

// DB access layer for products
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // All active products for a given seller
    List<Product> findBySellerIdAndIsActiveTrue(Long sellerId);

    // All active products in a specific category
    List<Product> findByCategoryAndIsActiveTrue(String category);
}
