// Modified by Gowthami
package com.gowthami.ecommerce.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/*
  Thrown when a requested entity (Seller, Product, Warehouse, Customer)
  does not exist in the database. Maps to HTTP 404.
*/
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }

    // Convenience constructor: "Seller not found with id: '999'"
    public ResourceNotFoundException(String entityName, String fieldName, Object fieldValue) {
        super(entityName + " not found with " + fieldName + ": '" + fieldValue + "'");
    }
}
