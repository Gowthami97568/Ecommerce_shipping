// Modified by Gowthami
package com.gowthami.ecommerce.service;

import com.gowthami.ecommerce.dto.NearestWarehouseResponse;
import com.gowthami.ecommerce.entity.Seller;
import com.gowthami.ecommerce.entity.Warehouse;
import com.gowthami.ecommerce.exception.NoWarehouseAvailableException;
import com.gowthami.ecommerce.exception.ResourceNotFoundException;
import com.gowthami.ecommerce.repository.ProductRepository;
import com.gowthami.ecommerce.repository.SellerRepository;
import com.gowthami.ecommerce.repository.WarehouseRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service responsible for finding the nearest active warehouse to a seller's
 * location.
 * When a customer places an order, the seller needs to know which warehouse
 * to drop their product at — this service answers that question.
 */
@Service
public class WarehouseService {

        private static final Logger log = LoggerFactory.getLogger(WarehouseService.class);

        private final SellerRepository sellerRepository;
        private final ProductRepository productRepository;
        private final WarehouseRepository warehouseRepository;
        private final GeoService geoService;

        @Autowired
        public WarehouseService(SellerRepository sellerRepository,
                        ProductRepository productRepository,
                        WarehouseRepository warehouseRepository,
                        GeoService geoService) {
                this.sellerRepository = sellerRepository;
                this.productRepository = productRepository;
                this.warehouseRepository = warehouseRepository;
                this.geoService = geoService;
        }

        /**
         * Find the nearest active warehouse for a given seller and product.
         *
         * The method:
         * 1. Validates that the seller and product exist and belong to each other.
         * 2. Loads all active warehouses.
         * 3. Computes the Haversine distance from the seller's location to each
         * warehouse.
         * 4. Returns the warehouse with the minimum distance.
         *
         * @param sellerId  ID of the seller
         * @param productId ID of the product (validated to belong to this seller)
         * @return a response DTO with the nearest warehouse details
         */
        public NearestWarehouseResponse findNearestWarehouse(Long sellerId, Long productId) {
                log.debug("Finding nearest warehouse for sellerId={}, productId={}", sellerId, productId);

                // 1. Validate seller exists
                Seller seller = sellerRepository.findById(sellerId)
                                .orElseThrow(() -> new ResourceNotFoundException("Seller", "id", sellerId));

                // 2. Validate product exists and belongs to this seller
                var product = productRepository.findById(productId)
                                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));

                if (!product.getSeller().getId().equals(sellerId)) {
                        throw new ResourceNotFoundException(
                                        "Product with id " + productId + " does not belong to seller with id "
                                                        + sellerId);
                }

                // 3. Load all active warehouses
                List<Warehouse> activeWarehouses = warehouseRepository.findByIsActiveTrue();
                if (activeWarehouses.isEmpty()) {
                        throw new NoWarehouseAvailableException(
                                        "No active warehouses are available in the system. Please contact support.");
                }

                // 4. Find the warehouse with the minimum distance from the seller's location
                Warehouse nearest = null;
                double minDistance = Double.MAX_VALUE;

                for (Warehouse warehouse : activeWarehouses) {
                        double distance = geoService.calculateDistanceKm(
                                        seller.getLatitude(), seller.getLongitude(),
                                        warehouse.getLatitude(), warehouse.getLongitude());
                        log.debug("Distance from seller {} to warehouse {}: {} km",
                                        seller.getSellerName(), warehouse.getWarehouseCode(), distance);

                        if (distance < minDistance) {
                                minDistance = distance;
                                nearest = warehouse;
                        }
                }

                log.info("Nearest warehouse for seller '{}' is '{}' at {} km",
                                seller.getSellerName(), nearest.getWarehouseCode(),
                                Math.round(minDistance * 100.0) / 100.0);

                // 5. Build and return the response
                NearestWarehouseResponse.LocationDto location = new NearestWarehouseResponse.LocationDto();
                location.setLat(nearest.getLatitude());
                location.setLng(nearest.getLongitude());

                NearestWarehouseResponse response = new NearestWarehouseResponse();
                response.setWarehouseId(nearest.getId());
                response.setWarehouseCode(nearest.getWarehouseCode());
                response.setWarehouseName(nearest.getWarehouseName());
                response.setCity(nearest.getCity());
                response.setWarehouseLocation(location);
                response.setDistanceFromSellerKm(Math.round(minDistance * 100.0) / 100.0);

                return response;
        }
}
