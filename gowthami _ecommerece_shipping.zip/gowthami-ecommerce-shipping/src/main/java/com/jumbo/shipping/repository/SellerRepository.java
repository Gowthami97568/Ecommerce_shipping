// Modified by Gowthami
package com.gowthami.ecommerce.repository;

import com.gowthami.ecommerce.entity.Seller;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// DB access layer for sellers
@Repository
public interface SellerRepository extends JpaRepository<Seller, Long> {
}
