// Modified by Gowthami
package com.gowthami.ecommerce.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/*
  Thrown when no active warehouses are registered in the system,
  making it impossible to fulfil the shipment. Maps to HTTP 503.
*/
@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
public class NoWarehouseAvailableException extends RuntimeException {

    public NoWarehouseAvailableException(String message) {
        super(message);
    }
}
