// Modified by Gowthami
package com.gowthami.ecommerce.service;

import org.springframework.stereotype.Service;

/*
  Calculates the straight-line distance between two geographic points
  using the Haversine formula, accounting for Earth's curvature.
  Returns the result in kilometres.
*/
@Service
public class GeoService {

    private static final double EARTH_RADIUS_KM = 6371.0;

    public double calculateDistanceKm(double lat1, double lng1, double lat2, double lng2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);

        double lat1Rad = Math.toRadians(lat1);
        double lat2Rad = Math.toRadians(lat2);

        // Haversine formula
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(lat1Rad) * Math.cos(lat2Rad)
                        * Math.sin(dLng / 2) * Math.sin(dLng / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return EARTH_RADIUS_KM * c;
    }
}
