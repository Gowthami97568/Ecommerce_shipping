// Modified by Gowthami
package com.gowthami.ecommerce.enums;

/*
  Delivery speed options available to the customer at checkout.

  STANDARD → Rs 10 flat charge + distance-based shipping
  EXPRESS  → Rs 10 flat charge + Rs 1.2 per kg surcharge + distance-based shipping
*/
public enum DeliverySpeed {
    STANDARD,
    EXPRESS
}
