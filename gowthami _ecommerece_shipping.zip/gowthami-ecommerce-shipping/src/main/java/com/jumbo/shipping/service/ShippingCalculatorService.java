// Modified by Gowthami
package com.gowthami.ecommerce.service;

import com.gowthami.ecommerce.dto.CalculateShippingRequest;
import com.gowthami.ecommerce.dto.CalculateShippingResponse;
import com.gowthami.ecommerce.dto.NearestWarehouseResponse;
import com.gowthami.ecommerce.dto.ShippingChargeResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Orchestrator service that combines the nearest-warehouse lookup and shipping
 * charge calculation into a single operation.
 *
 * This is the service behind POST /api/v1/shipping-charge/calculate.
 * It delegates to WarehouseService and ShippingChargeService, keeping each
 * service focused on a single responsibility.
 */
@Service
public class ShippingCalculatorService {

        private static final Logger log = LoggerFactory.getLogger(ShippingCalculatorService.class);

        private final WarehouseService warehouseService;
        private final ShippingChargeService totalShippingCostService;

        @Autowired
        public ShippingCalculatorService(WarehouseService warehouseService,
                        ShippingChargeService totalShippingCostService) {
                this.warehouseService = warehouseService;
                this.totalShippingCostService = totalShippingCostService;
        }

        /**
         * Calculate the complete shipping charge for a seller → customer order.
         *
         * Steps:
         * 1. Find the nearest warehouse to the seller's location.
         * 2. Use that warehouse as the shipping origin to calculate the charge to the
         * customer.
         * 3. Return both results combined in a single response.
         *
         * @param request contains sellerId, productId, customerId, and deliverySpeed
         * @return combined response with the nearest warehouse and shipping charge
         *         breakdown
         */
        public CalculateShippingResponse calculate(CalculateShippingRequest request) {
                log.info("Starting shipping calculation: sellerId={}, customerId={}, productId={}, speed={}",
                                request.getSellerId(), request.getCustomerId(),
                                request.getProductId(), request.getDeliverySpeed());

                // Step 1: Resolve the nearest warehouse for the seller
                NearestWarehouseResponse nearestWarehouse = warehouseService.findNearestWarehouse(
                                request.getSellerId(), request.getProductId());

                // Step 2: Calculate shipping charge from that warehouse to the customer
                ShippingChargeResponse totalShippingCost = totalShippingCostService.computeShippingCostCharge(
                                nearestWarehouse.getWarehouseId(),
                                request.getCustomerId(),
                                request.getProductId(),
                                request.getDeliverySpeed());

                log.info("Shipping calculation complete: warehouseId={}, totalCharge={} Rs",
                                nearestWarehouse.getWarehouseId(), totalShippingCost.getShippingCharge());

                CalculateShippingResponse response = new CalculateShippingResponse();
                response.setShippingCharge(totalShippingCost.getShippingCharge());
                response.setNearestWarehouse(nearestWarehouse);
                response.setShippingDetails(totalShippingCost);

                return response;
        }
}
