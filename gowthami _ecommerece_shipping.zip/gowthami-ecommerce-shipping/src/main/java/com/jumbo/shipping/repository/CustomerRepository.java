// Modified by Gowthami
package com.gowthami.ecommerce.repository;

import com.gowthami.ecommerce.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

// DB access layer for customers
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    // Look up a customer by their business code (e.g. "Cust-123")
    Optional<Customer> findByCustomerCode(String customerCode);
}
