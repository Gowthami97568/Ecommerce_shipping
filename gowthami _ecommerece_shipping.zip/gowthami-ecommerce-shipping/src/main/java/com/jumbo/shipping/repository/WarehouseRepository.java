// Modified by Gowthami
package com.gowthami.ecommerce.repository;

import com.gowthami.ecommerce.entity.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

// DB access layer for warehouses
@Repository
public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {

    // Returns only active warehouses — used during nearest warehouse lookup
    List<Warehouse> findByIsActiveTrue();
}
