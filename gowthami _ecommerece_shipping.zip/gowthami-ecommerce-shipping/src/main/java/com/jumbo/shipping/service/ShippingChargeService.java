// Modified by Gowthami
package com.gowthami.ecommerce.service;

import com.gowthami.ecommerce.dto.ShippingChargeResponse;
import com.gowthami.ecommerce.entity.Customer;
import com.gowthami.ecommerce.entity.Product;
import com.gowthami.ecommerce.entity.Warehouse;
import com.gowthami.ecommerce.enums.DeliverySpeed;
import com.gowthami.ecommerce.enums.TransportMode;
import com.gowthami.ecommerce.exception.InvalidInputException;
import com.gowthami.ecommerce.exception.ResourceNotFoundException;
import com.gowthami.ecommerce.repository.CustomerRepository;
import com.gowthami.ecommerce.repository.ProductRepository;
import com.gowthami.ecommerce.repository.WarehouseRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service responsible for calculating the shipping charge from a warehouse to a
 * customer.
 *
 * Pricing rules:
 * - Base: distance × weight × transport rate
 * - Standard: Rs 10 flat + base charge
 * - Express: Rs 10 flat + Rs 1.2/kg express surcharge + base charge
 *
 * Transport mode is determined automatically by distance:
 * - Mini Van : 0–100 km → Rs 3/km/kg
 * - Truck : 100–500 km → Rs 2/km/kg
 * - Aeroplane : 500+ km → Rs 1/km/kg
 */
@Service
public class ShippingChargeService {

        private static final Logger log = LoggerFactory.getLogger(ShippingChargeService.class);

        /** Fixed courier handling fee applied to all orders regardless of speed. */
        private static final double STANDARD_COURIER_CHARGE_RS = 10.0;

        /** Additional surcharge per kilogram applied only for EXPRESS delivery. */
        private static final double EXPRESS_SURCHARGE_PER_KG_RS = 1.2;

        private final WarehouseRepository warehouseRepository;
        private final CustomerRepository customerRepository;
        private final ProductRepository productRepository;
        private final GeoService geoService;

        @Autowired
        public ShippingChargeService(WarehouseRepository warehouseRepository,
                        CustomerRepository customerRepository,
                        ProductRepository productRepository,
                        GeoService geoService) {
                this.warehouseRepository = warehouseRepository;
                this.customerRepository = customerRepository;
                this.productRepository = productRepository;
                this.geoService = geoService;
        }

        /**
         * Calculate the shipping charge for a given warehouse → customer route.
         *
         * @param warehouseId   ID of the source warehouse
         * @param customerId    ID of the destination customer (Kirana store)
         * @param productId     ID of the product being shipped (weight is needed for
         *                      pricing)
         * @param deliverySpeed STANDARD or EXPRESS
         * @return detailed shipping charge response including breakdown
         */
        public ShippingChargeResponse computeShippingCostCharge(
                        Long warehouseId, Long customerId, Long productId, DeliverySpeed deliverySpeed) {

                log.debug("Calculating shipping charge: warehouseId={}, customerId={}, productId={}, speed={}",
                                warehouseId, customerId, productId, deliverySpeed);

                // Validate all input entities
                Warehouse warehouse = warehouseRepository.findById(warehouseId)
                                .orElseThrow(() -> new ResourceNotFoundException("Warehouse", "id", warehouseId));

                Customer customer = customerRepository.findById(customerId)
                                .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));

                Product product = productRepository.findById(productId)
                                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));

                if (!warehouse.getIsActive()) {
                        throw new InvalidInputException(
                                        "Warehouse '" + warehouse.getWarehouseCode() + "' is not active.");
                }

                // Calculate distance from warehouse to customer
                double distanceKm = geoService.calculateDistanceKm(
                                warehouse.getLatitude(), warehouse.getLongitude(),
                                customer.getLatitude(), customer.getLongitude());

                log.debug("Distance from warehouse '{}' to customer '{}': {} km",
                                warehouse.getWarehouseCode(), customer.getStoreName(), distanceKm);

                // Determine the applicable transport mode based on distance
                TransportMode transportMode = TransportMode.fromDistance(distanceKm);

                // Compute each charge component
                double weightKg = product.getWeightKg();
                double distanceBasedCharge = distanceKm * weightKg * transportMode.getRatePerKmPerKg();
                double expressSurcharge = (deliverySpeed == DeliverySpeed.EXPRESS)
                                ? EXPRESS_SURCHARGE_PER_KG_RS * weightKg
                                : 0.0;

                double totalCharge = STANDARD_COURIER_CHARGE_RS + expressSurcharge + distanceBasedCharge;

                // Round to 2 decimal places for currency display
                double roundedTotal = Math.round(totalCharge * 100.0) / 100.0;
                double roundedDistance = Math.round(distanceKm * 100.0) / 100.0;

                log.info("Shipping charge calculated: total={} Rs, mode={}, distance={} km, speed={}",
                                roundedTotal, transportMode, roundedDistance, deliverySpeed);

                ShippingChargeResponse.ChargeBreakdown breakdown = new ShippingChargeResponse.ChargeBreakdown();
                breakdown.setStandardCourierChargeRs(STANDARD_COURIER_CHARGE_RS);
                breakdown.setExpressSurchargeRs(Math.round(expressSurcharge * 100.0) / 100.0);
                breakdown.setDistanceBasedChargeRs(Math.round(distanceBasedCharge * 100.0) / 100.0);
                breakdown.setTotalChargeRs(roundedTotal);

                ShippingChargeResponse response = new ShippingChargeResponse();
                response.setShippingCharge(roundedTotal);
                response.setDistanceKm(roundedDistance);
                response.setTransportMode(transportMode);
                response.setDeliverySpeed(deliverySpeed);
                response.setBreakdown(breakdown);

                return response;
        }
}
