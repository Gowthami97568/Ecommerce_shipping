// Modified by Gowthami
package com.gowthami.ecommerce.enums;

/*
  Transport modes used for shipping, determined automatically by distance.

  MINI_VAN  →  0–100 km   →  Rs 3 per km per kg
  TRUCK     →  100–500 km →  Rs 2 per km per kg
  AEROPLANE →  500+ km    →  Rs 1 per km per kg
*/
public enum TransportMode {

    MINI_VAN(0, 100, 3.0),
    TRUCK(100, 500, 2.0),
    AEROPLANE(500, Double.MAX_VALUE, 1.0);

    private final double minDistanceKm;
    private final double maxDistanceKm;
    private final double ratePerKmPerKg;

    TransportMode(double minDistanceKm, double maxDistanceKm, double ratePerKmPerKg) {
        this.minDistanceKm = minDistanceKm;
        this.maxDistanceKm = maxDistanceKm;
        this.ratePerKmPerKg = ratePerKmPerKg;
    }

    public double getMinDistanceKm() {
        return minDistanceKm;
    }

    public double getMaxDistanceKm() {
        return maxDistanceKm;
    }

    public double getRatePerKmPerKg() {
        return ratePerKmPerKg;
    }

    // Returns the correct transport mode for a given distance
    public static TransportMode fromDistance(double distanceKm) {
        for (TransportMode mode : values()) {
            if (distanceKm >= mode.minDistanceKm && distanceKm < mode.maxDistanceKm) {
                return mode;
            }
        }
        return AEROPLANE;
    }
}
