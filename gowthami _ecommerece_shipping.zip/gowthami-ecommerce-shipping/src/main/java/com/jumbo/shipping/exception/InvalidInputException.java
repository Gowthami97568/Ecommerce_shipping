// Modified by Gowthami
package com.gowthami.ecommerce.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/*
  Thrown when the client sends invalid data, such as an inactive warehouse ID
  or an unsupported delivery speed. Maps to HTTP 400.
*/
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidInputException extends RuntimeException {

    public InvalidInputException(String message) {
        super(message);
    }
}
