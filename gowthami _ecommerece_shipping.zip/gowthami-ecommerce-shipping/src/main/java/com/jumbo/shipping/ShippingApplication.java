// Modified by Gowthami
package com.gowthami.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
  Entry point for the Shipping Charge Estimator API.
  Spring Boot auto-configures JPA, the web server, and component scanning.
*/
@SpringBootApplication
public class ShippingApplication {
    public static void main(String[] args) {
        SpringApplication.run(ShippingApplication.class, args);
    }
}
